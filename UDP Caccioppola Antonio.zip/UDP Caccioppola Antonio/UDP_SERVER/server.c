#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <netdb.h>
#include "operation.h"
#include "apisocket.h"

void errorHandler(char *errorMessage) {
    printf ("%s", errorMessage);
}

int main(int argc, char *argv[]) {
 
    if(initSocket() != SUCCESS){
        errorHandler("Something went wrong during WSA Startup");
    }else{
        printf("Socket API initialized\n");
    }
    char *hostname="localhost";

    struct hostent* myself=gethostbyname(hostname);
    struct in_addr* myaddress =(struct in_addr*)myself->h_addr_list[0];
    
    int server_socket,client_socket;
    struct sockaddr_in server_address, client_address;
    int server_port = PROTOPORT;
    
    if(argc==2){
        server_port=atoi(argv[1]);
    }else if(argc>2){
        errorHandler("Invalid arguments");
        return -1;
    }
    
    if((server_socket=socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP))<0){
        errorHandler("socket creation failed\n");
        return -1;
    }
    
    memset(&server_address, 0, sizeof((server_address)));
    server_address.sin_family=PF_INET;
    server_address.sin_addr=*myaddress;
    server_address.sin_port=htons(server_port);
    
    if(bindSocket(server_socket, server_address)<0){
        errorHandler("bind failed\n");
        return -1;
    }else{
        printf("bind success\n");
    }
    
    printf("Server online\n");
    printf("Ready for connection..\n");
    
    unsigned int address_len;
    unsigned long int messagesize;
    string recvmessage=createaString(1024);
    address_len=sizeof(client_address);
    messagesize=recvfrom(server_socket, recvmessage, 1024, 0, (struct sockaddr*)&client_address, &address_len);
    
    printf("%s\n", recvmessage);
    struct hostent* mario=gethostbyaddr((char*)&client_address.sin_addr, 4, AF_INET);
    struct in_addr* server_in_address = (struct in_addr*) mario->h_addr_list[0];

    printf("Client Name    > %s\n", mario->h_name);
    printf("Client Address > %s\n", inet_ntoa(*server_in_address));
    
    sendto(server_socket, "OK\0", 3, 0,(struct sockaddr*)&client_address, sizeof(client_address));
    char opreceived[30];
    messagesize=0;

    char *result;
    int c;
    while(1){
        fflush(stdin);
        if((messagesize=recvfrom(server_socket, opreceived, 30, 0, (struct sockaddr*)&client_address, &address_len))<0){
            errorHandler("Recv error.");
        }
        printf("\nOperation request '%s' from client %s, ip %s",opreceived, mario->h_name, inet_ntoa(*server_in_address));
        operation op=readOperation(opreceived);

        result=generateOpMsg(op);
        printf("\n%s",result);
        sendto(server_socket, result, 1024, 0, (struct sockaddr*)&client_address, sizeof(client_address));
        
    }
    
}

        


