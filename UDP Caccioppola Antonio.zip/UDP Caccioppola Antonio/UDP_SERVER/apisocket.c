
#include "apisocket.h"

int initSocket(){
    #if defined WIN32
        WSADATA wsadata;
        if(WSAStartup(MAKEWORD(2,2), &wsadata) != 0){
            return ERROR;
        }
    #endif

    return SUCCESS;
}

void closeSocket(int socket){
    #if defined WIN32
        closesocket(socket);
        WSACleanup();
    #else
        close(socket);
    #endif
}

int bindSocket(int socket, struct sockaddr_in address){
    return bind(socket, (struct sockaddr*)&address, sizeof(address));
}


char *generateOpMsg(operation op){
    char buffer[DEF_BUFFER] = "";

    switch(op.op){
        case '+':
            sprintf(buffer, "%d + %d = %.1f\0", op.a, op.b, (double)(op.a + op.b));
            break;
        case '-':
            sprintf(buffer, "%d - %d = %.1f\0", op.a, op.b, (double)(op.a - op.b));
            break;
        case '/':
            if(op.b == 0){
                    sprintf(buffer, " %d / %d = error\0", op.a, op.b);
            }else{
                    sprintf(buffer, "%d / %d = %.1f\0", op.a, op.b, (double)(op.a / op.b));
            }
            break;
        case '*':
            sprintf(buffer, "%d * %d = %.1f\0", op.a, op.b, (double)(op.a * op.b));
            break;

    }

    char* result_message = (char *) malloc(sizeof(char) * strlen(buffer));
    strcpy(result_message, buffer);
    return result_message;
}

