
#include "operation.h"

char intochar(int i){
    return i + '0';
}

int chartoint(char c){
    return c - '0';
}



operation readOperation(char oprecvd[30]){
    //fflush(stdin);
    //char temp[512];
    operation op;
    //fgets(oprecvd,30,stdin);
    const char seps[2]=" ";
    char *token;
    token= strtok(oprecvd, seps);
    op.op=(*token);
    token=strtok(NULL, seps);
    op.a=atoi(token);
    token=strtok(NULL, seps);
    op.b=atoi(token);
    return op;
}

string createaString(unsigned long size){
    return (string) malloc(sizeof(char) * size);
}
