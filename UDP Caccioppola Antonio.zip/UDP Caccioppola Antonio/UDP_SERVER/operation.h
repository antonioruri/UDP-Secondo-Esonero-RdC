
#ifndef operation_h
#define operation_h

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define ERROR -1
#define SUCCESS 0

typedef char* string;
typedef struct operation{
    char op; //operator
    int a; //first operand
    int b; //second operand
}operation;

char intochar(int i);
int chartoint(char c);//convert an input integer to a char

operation readOperation(char oprecvd[30]);
string createaString(unsigned long size);

#endif /* operation_h */
