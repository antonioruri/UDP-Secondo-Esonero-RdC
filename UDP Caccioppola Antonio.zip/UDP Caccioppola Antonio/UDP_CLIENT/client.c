
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <netdb.h>
#include "operation.h"
#include "apisocket.h"

void errorHandler(char *errorMessage) {
    printf ("%s", errorMessage);
}

int main() {

    if(initSocket()!=0){
        errorHandler("[WINSOCK] not initilized");
    }
    
    // CLient socket creation
    int client_socket;
    client_socket = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (client_socket < 0) {
        errorHandler("Socket creation failed.\n");
        return -1;
    }
    
    struct sockaddr_in server_address;
    char *server_saddr;
    int server_port;
    
    char str[30];
    const char p[2]=":";
    char *token;
    printf("Insert host address and port: \nEX. srv.di.uniba.it:56700\n");
    fflush(stdin);
    fgets(str, 30, stdin);
    token=strtok(str,p);
    server_saddr=token;
    token=strtok(NULL,p);
    server_port=atoi(token);
    
    struct hostent* server_hostent=gethostbyname(server_saddr);
    struct in_addr* server_in_address;
    
    if(server_hostent!=NULL){
        server_in_address=(struct in_addr*) server_hostent->h_addr_list[0];
        if(server_hostent!=NULL){

            printf("\nconnect to server: %s", server_hostent->h_name);

            printf("\nServer address: %s\n", inet_ntoa(*server_in_address));
            
        }else{
            errorHandler("Error ip");
            return -1;
        }
    }else{
        errorHandler("Error hostname");
        return -1;
    }
        
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = inet_addr(inet_ntoa(*server_in_address));
    server_address.sin_port = htons(PROTOPORT);
    
    sendto(client_socket, "\nINIZIO PROCESSO CLIENT\0\n", 1024, 0, (struct sockaddr*)&server_address, sizeof(server_address));
    
    string recvmessage=createaString(1024);
    string opresult=createaString(1024);
    unsigned long int messagesize;
    unsigned int address_len=sizeof(server_address);
    messagesize=recvfrom(client_socket, recvmessage, 1024, 0, (struct sockaddr*)&server_address, &address_len);
    printf("%s", recvmessage);
    char optosend[30];
    char m; //service char to test when client close connection
    while((m!='=')){
        printf("\nInsert operation: \nUse one of this +,-,/,* operators and two integer operands\nEX. + 17 92\n");
        
        fflush(stdin);
        fgets(optosend,30,stdin);
        if(sendto(client_socket, optosend, 30, 0, (struct sockaddr*)&server_address, sizeof(server_address))==0){
            errorHandler("Sent error.");
        }
        
        if((messagesize=recvfrom(client_socket, opresult, 1024, 0, (struct sockaddr*)&server_address, &address_len))<0){
            errorHandler("Recv error.");
        }
        printf("Received result from server %s, ip %s: %s ",server_hostent->h_name,inet_ntoa(*server_in_address), opresult);
        printf("\nPress ENTER for a new operation or press '=' to quit.");
        m=getchar();
   }
    closeSocket(client_socket);
    return EXIT_SUCCESS;
}
